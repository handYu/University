module.exports = {
  presets: [
    '@vue/app'
  ],
  "ignore": [
    "./src/lib/mui/js/mui.min.js"
  ]
}
