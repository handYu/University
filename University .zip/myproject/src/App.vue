<template>
 <div class="app-container">
    <router-view></router-view>
 </div>
</template>

<style>
   *{
      padding:0;
      margin:0;
   }
   html{
      font-size:16px;
   }
</style>
