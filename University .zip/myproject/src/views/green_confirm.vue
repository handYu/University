<template>
    <div id="green_confirm">
        <mt-button type="primary" size="large">提交</mt-button>
    </div>
</template>
<script>
    export default{
        data(){
            return{

            }
        }
    }
</script>
<style scoped>
    
</style>